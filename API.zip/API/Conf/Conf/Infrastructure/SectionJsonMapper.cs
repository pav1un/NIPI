﻿using System;
using Conf.Models;


namespace Conf.Infrastructure
{
    public class SectionJsonMapper
    {
		public object ToJson(Section section) =>
			section == null 
				? new object()
				: section.Info == null
					? new { section = section.Code, info = new { name = "", city = "", location = "" } }
					: new {
							section = section.Code,
							info = new {
								name = section.Info.Name,
								city = section.Info.City,
								location = section.Info.Location
							}
					};

		public Section ToSection(string code, SectionInfo info) =>
			 new Section() { Code = code, Info = info };

    }
}
