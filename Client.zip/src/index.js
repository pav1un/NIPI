import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import {createStore, combineReducers} from 'redux';
import sections from './reducers/sections';

const baseUrl = 'http://localhost:58629';

const store = createStore(
    combineReducers({sections})
);

const render = () => ReactDOM.render(
    <App store={store} baseUrl={baseUrl} />, 
    document.getElementById('root')
);

store.subscribe(render);
render();

registerServiceWorker();
