﻿using System;


namespace Conf.Infrastructure
{
    public class LiteDBConfiguration
    {
		public string ConnectionString { get; set; }
    }
}
