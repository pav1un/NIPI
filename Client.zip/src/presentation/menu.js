import React  from 'react';

import '../css/menubtn.css';

const Menubtn = ({onAdd, onAllUpdate}) => 
    <div align="center" className="menubtn">
        <button className="all-update-btn" onClick={onAllUpdate}> Получить список всех секций </button>

        <div className="new-section-block">
            <button onClick={() => onAdd(
                this.code.value, 
                this.name.value, 
                this.city.value, 
                this.location.value
            )}> 
              Добавить секцию 
            </button>
            
            <input type="text" placeholder="Секция" ref={el => this.code = el} /> 
            <input type="text" placeholder="Полное название секции" ref={el => this.name = el} /> 
            <input type="text" placeholder="Город" ref={el => this.city = el} /> 
            <input type="text" placeholder="Расположение" ref={el => this.location = el} /> 
        </div>
    </div>    



export default Menubtn;