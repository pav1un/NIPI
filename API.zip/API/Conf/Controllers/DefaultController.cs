﻿using Microsoft.AspNetCore.Mvc;
using System;
using WebApiContrib.Formatting.Jsonp;

namespace Conf.Controllers
{
    public class DefaultController : Controller
    {
        private readonly System.Web.Http.HttpConfiguration _httpConfig;

        public DefaultController(System.Web.Http.HttpConfiguration config) {
            _httpConfig = config ?? throw new ArgumentNullException(nameof(config));

            _httpConfig.Formatters.Insert(0, new JsonpMediaTypeFormatter(config.Formatters.JsonFormatter));
        }

        public new IActionResult NotFound()
            => new JsonResult(new { NotFound = "NotFound" });
    }
}