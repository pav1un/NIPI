﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Conf.Infrastructure;
using System.Web.Http;

namespace Conf
{
    public class Startup
    {
        public Startup(IConfiguration configuration) {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services) {
            services.AddMvc();

            services.AddCors(opt =>
                opt.AddPolicy("AllowAllOrigins", bldr => 
                    bldr.AllowAnyOrigin()
                        .AllowAnyHeader()
                        .AllowAnyMethod()));

			services.Configure<LiteDBConfiguration>(Configuration.GetSection("liteDB"));

            services.AddSingleton<ISectionStorage, LiteDBSectionStorage>();
            services.AddScoped<HttpConfiguration>();
			services.AddScoped<SectionJsonMapper>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env) {
			if (env.IsDevelopment())
                app.UseDeveloperExceptionPage();

            app.UseCors("AllowAllOrigins");

            app.UseMvc(routes => {
                // unresolved routes
                routes.MapRoute(
                    "Default",
                    "{*url}",
                    defaults: new { controller = "Default", action = "NotFound" });
            });
        }
    }
}
