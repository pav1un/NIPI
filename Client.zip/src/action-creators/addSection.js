import actions from "../actions/actions";

const addSection = (code, name, city, location) => ({
    type: actions.ADD_SECTION,
    section: {
        section: code,
        info: {
            name, 
            city,
            location
        }
    }
});


export default addSection;
