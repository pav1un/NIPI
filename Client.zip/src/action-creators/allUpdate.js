import actions from "../actions/actions";

const allUpdate = (sections) => ({
    type: actions.ALL_UPDATE,
    sections: sections
});


export default allUpdate;
