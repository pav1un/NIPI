import actions from "../actions/actions";

const sections = (state = [], action) => {
    switch(action.type) {
        case actions.ADD_SECTION: 
            return [...state, action.section];

        case actions.UPDATE_SECTION: 
            return state.map(s => 
                s.code !== action.section.code 
                    ? s 
                    : action.section);

        case actions.ALL_UPDATE: 
            return action.sections;

        default: return state;
    }
}

export default sections;
