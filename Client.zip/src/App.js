import React, { Component } from 'react';

import Menubtn from './presentation/menu';
import Sections from './presentation/sections';
import allUpdate from './action-creators/allUpdate';
import updateSection from './action-creators/updateSection';
import addSection from './action-creators/addSection';

class App extends Component {
  constructor(props) {
    super(props);

    this.updateAllSections = this.updateAllSections.bind(this);
    this.updateSect = this.updateSect.bind(this);
    this.modifySection = this.modifySection.bind(this); 
    this.addSect = this.addSect.bind(this); 

    this.baseUrl = props.baseUrl;
    this.store = props.store;

    this.state = {
      isLoading: true
    }
  }

  componentWillMount() {
    // this.updateAllSections();
  }

  updateAllSections() {
    fetch(this.baseUrl + '/Conference/info')
      .then(res => res.json())
      .then(json => {
        this.store.dispatch(allUpdate(json));
        this.setState( {isLoading: false}); 
        alert('Updated');
      })
      .catch(err => console.log(err)); // TODO
  } 

  updateSect(code, name, city, location) {
    if(!code || !name || !city || !location) {
      alert('All values should be entered');
      return;
    }

    this.modifySection({code, name, city, location}, 'PUT')
    .then(res => {
      if (res)  {
        this.store.dispatch(updateSection(code, name, city, location));
        alert('was updated');
      } else alert('already exists');        
    }).catch(err => console.log(err)); 
  }

  addSect(code, name, city, location) {
    if(!code || !name || !city || !location) {
      alert('All values should be entered');
      return;
    }

    this.modifySection({code, name, city, location}, 'POST')
      .then(res => {
        if (res)  {
          this.store.dispatch(addSection(code, name, city, location));
          alert('was added');
        } else alert('already exists');  
      }).catch(err => console.log(err));
  }

  modifySection(data, method) {
    return new Promise((resolve, reject) => {
      const {code} = data; 

      fetch(this.baseUrl + `/Conference/${code}/info`, 
            { method: method, 
              body: JSON.stringify(data),
              headers: { "Content-Type": "application/json" }})
        .then(res => {
          this.setState({isLoading: false});
          return resolve(res.json());
        })
        .catch(err => reject(err));  
    });
  }

  render() {
    return (
      <div className="App">
         <Menubtn onAdd={this.addSect}
                  onAllUpdate={this.updateAllSections}>
         </Menubtn>

         <Sections sctns={this.store.getState().sections}
                   onUpdate={this.updateSect}>
         </Sections>
      </div>
    );
  }
} 

export default App;
