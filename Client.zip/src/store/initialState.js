
const initialState = {
    sections: []
}


export default initialState;