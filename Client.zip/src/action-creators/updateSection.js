import actions from "../actions/actions";

const updateSection = (code, name, city, location) => ({
    type: actions.UPDATE_SECTION,
    section: {
        code,
        name, 
        city,
        location
    }
});


export default updateSection;
