﻿using Microsoft.AspNetCore.Mvc;
using System;

namespace Conf.Controllers
{
    public class DefaultController : Controller
    { 
        public new IActionResult NotFound()
            => new JsonResult(new { NotFound = "NotFound" });
    }
}