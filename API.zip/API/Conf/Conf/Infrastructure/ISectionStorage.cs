﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Conf.Models;
using LiteDB;
using Microsoft.Extensions.Options;

namespace Conf.Infrastructure
{
    /// <summary>
    /// Simple storage abstraction for section
    /// </summary>
    public interface ISectionStorage
    {
        Task<Section> GetSection(string name);
        Task<IQueryable<Section>> GetSections(); 
        Task<bool> Insert(Section section);
        Task<bool> Update(Section section);

    }

    public class LiteDBSectionStorage : ISectionStorage
	{
		private const string CollectionName = "Section";
		private readonly LiteDBConfiguration _dbConfig;

		public LiteDBSectionStorage(IOptions<LiteDBConfiguration> dbConfig) =>
			_dbConfig = dbConfig.Value ?? throw new ArgumentNullException(nameof(dbConfig));


        public async Task<Section> GetSection(string code) =>
            GetCollect()?.FindOne(s => s.Code == code);


        public async Task<IQueryable<Section>> GetSections() =>
            GetCollect()?.FindAll().AsQueryable();

        public async Task<bool> Insert(Section section) {
            if (GetSectionIfExists(section.Code) != null)
                return false;

            GetCollect().Insert(section);

            return true;
        }

        public async Task<bool> Update(Section section) {
            var sect = GetSectionIfExists(section.Code);

            if (sect != null) {
                CloneSection(section, ref sect);
                GetCollect().Update(sect);

                return true; 
            }

            return false;
        }

        private void CloneSection(Section src, ref Section dst) {
            dst.Code = src.Code;
            dst.Info = src.Info;
        }

        private Section GetSectionIfExists(string code) =>
             GetCollect()?.FindOne(s => s.Code == code);

        private LiteCollection<Section> GetCollect() {
            using (var db = new LiteDatabase(_dbConfig.ConnectionString)) {
                return db.GetCollection<Section>(CollectionName);
            }
        }
    }
}
