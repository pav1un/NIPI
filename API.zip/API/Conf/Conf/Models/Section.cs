﻿using System;
using LiteDB;


namespace Conf.Models
{
    public class Section
    {
        public ObjectId Id { get; set; } // only for liteDB
        public string Code { get; set; }
        public SectionInfo Info { get; set; }
    }

    public class SectionInfo
    {
        public string Name { get; set; }
        public string City { get; set; }
        public string Location { get; set; } 
    }
}
