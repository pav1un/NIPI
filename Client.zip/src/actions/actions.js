const actions = {
    ADD_SECTION: "ADD_SECTION",
    UPDATE_SECTION: "UPDATE_SECTION",
    ALL_UPDATE: "ALL_UPDATE"
}

export default actions;