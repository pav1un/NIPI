import React  from 'react';
import Section from "./section";

import '../css/sections.css';

const Sections = ({sctns = [], onUpdate}) => 
    <div align="center" className="sections">
        { sctns && sctns.length > 0 
            ? <table>
                <tbody>
                    {sctns.map((s, i) => 
                        <Section code={s.section} 
                                 name={s.info.name}
                                 city={s.info.city}
                                 location={s.info.location}
                                 onUpdate={onUpdate}
                                 number={i} 
                                 key={i}>
                        </Section>
                    )}
                </tbody>
              </table>
            : "No sections yet" 
        }
    </div>

export default Sections;
