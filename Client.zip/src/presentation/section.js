import React  from 'react';

const Section = ({code, name, city, location, onUpdate, number}) => 
    <tr>
        <td><input type="text" defaultValue={code} readOnly  ref={ el => this['codeInput' + number] = el } /> </td>
        <td><input type="text" defaultValue={name}  ref={ el => this['nameInput' + number] = el }/> </td>
        <td><input type="text" defaultValue={city}  ref={ el => this['cityInput' + number] = el }/> </td>
        <td><input type="text" defaultValue={location} ref={ el => this['locationInput' + number] = el }/> </td>
        <td>
            <button onClick={() => 
                onUpdate(
                    this['codeInput' + number].value, 
                    this['nameInput' + number].value, 
                    this['cityInput' + number].value, 
                    this['locationInput' + number].value)}> 

                Обновить
            </button>
        </td>
    </tr>


export default Section;
